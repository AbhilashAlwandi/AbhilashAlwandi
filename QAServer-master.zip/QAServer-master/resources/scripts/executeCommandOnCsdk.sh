#!/bin/bash
# Author : kiran
# Runs the commands in demo app

if [ "$#" -ne 3 ]; then
    echo "Usage ./executeCommandOnCsdk COMMAND DEVICE_ID BACKGROUND"
	exit 1
fi

CSDK_DIR='/usr/local/qa/DHRD-Edge-SDK'

CMD_TO_RUN=$1
DEVICE_ID=$2
BACKGROUND=$3

MASTER_CERTS_DIR=${CSDK_DIR}/certDirectory
AUTOMATION_DEV_CERTS_DIR=${MASTER_CERTS_DIR}/AutomationDeviceCerts
DEVICE_ID_CERTS=${AUTOMATION_DEV_CERTS_DIR}/${DEVICE_ID}
#Folder names with space differentiating each folder
FOLDERS_REQUIRED_FOR_AUTOMATION="General Notifications"
#The folder should be part of FOLDERS_REQUIRED_FOR_AUTOMATION
SYMBOLIC_LINK_FOLDER="General"
DEVICE_ID_LOGS=${DEVICE_ID_CERTS}/edge.log	

sudo chown -R ubuntu:ubuntu ${CSDK_DIR}
sudo chmod -R a+rwx ${CSDK_DIR}

mkdir -p ${AUTOMATION_DEV_CERTS_DIR}

if [ -d "$DEVICE_ID_CERTS" ]; then
  echo "Certs directory exists doing nothing"
else
  echo "Certs directory does not exist. Creating a new directory & preparing the directory for automation usage"
  mkdir ${DEVICE_ID_CERTS}
  cp -r ${MASTER_CERTS_DIR}/httpsCert ${DEVICE_ID_CERTS}
  
  echo "Creating the required folders for automation"
  for dir in ${FOLDERS_REQUIRED_FOR_AUTOMATION}
  do
	mkdir -p ${DEVICE_ID_CERTS}/${dir}
  done
  
  echo "Creating symbolic link to a text file in General folder"
  cd ${DEVICE_ID_CERTS}/${SYMBOLIC_LINK_FOLDER} && ln -s ${CSDK_DIR}/AUTHORS
  cd -
fi

printf $CMD_TO_RUN > ${DEVICE_ID_CERTS}/command.txt
chmod +x ${DEVICE_ID_CERTS}/command.txt
cat ${DEVICE_ID_CERTS}/command.txt

if [ "$BACKGROUND" == "true" ]; then
  nohup stdbuf -o0 ${CSDK_DIR}/demo/dhrdconnect_demo ${DEVICE_ID_CERTS}/command.txt > ${DEVICE_ID_LOGS} 2>&1 &
else
  nohup stdbuf -o0 ${CSDK_DIR}/demo/dhrdconnect_demo ${DEVICE_ID_CERTS}/command.txt > ${DEVICE_ID_LOGS} 2>&1
fi

#SECONDS=1
#interval=1

#echo "Seconds : ${SECONDS}, Interval : ${interval}, Logs folder : ${DEVICE_ID_LOGS}"

#while ((${SECONDS} <= ${TIMEOUT}))
#do
#  file_contents="$(grep "${PATTERN}" "${DEVICE_ID_LOGS}")"
#  if [ -n "$file_contents" ]
#  then
#    echo "Pattern matched"
#	break
#  else
#	echo "Pattern not matched. Retrying"
#    sleep ${interval}
#  fi
#done

#if [ ${SECONDS} -gt ${TIMEOUT} ]
#then
#	echo "Pattern did not match. Killing process if it exists"
#	pkill -f ${DEVICE_ID_CERTS} -9
#fi
package com.dhrd.qa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dhrd.qa.model.CsdkExecuteCommand;
import com.dhrd.qa.model.CsdkUpdate;
import com.dhrd.qa.service.ICsdkService;

@RestController
@RequestMapping("/csdk")
public class CsdkController {
	
	@Autowired
	ICsdkService csdkService;
	
	@PostMapping("/execute_command")
	public ResponseEntity<?> executeCommand(@RequestBody CsdkExecuteCommand cmd) {
		String res = csdkService.executeCommand(cmd);
		
		if(res.contains("CsdkService::Failure")) {
			return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}else {
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
	}
	
	@DeleteMapping("/delete_device_certs/{device_id}")
	public String deleteDeviceCerts(@PathVariable String device_id) {
		return csdkService.deleteDeviceCerts(device_id);
	}
	
	@DeleteMapping("/kill_csdk_process/{device_id}")
	public String killCsdkProcess(@PathVariable String device_id) {
		return csdkService.killCsdkProcess(device_id);
	}
	
	@DeleteMapping("/cleanup_device_state/{device_id}")
	public String cleanupDeviceState(@PathVariable String device_id) {
		String s1=csdkService.killCsdkProcess(device_id);
		String s2=csdkService.deleteDeviceCerts(device_id);
		return s1+"\n"+s2;
	}
	
	@PostMapping("/edge_log")
	public ResponseEntity<?> getEdgeLog(@RequestBody CsdkExecuteCommand cmd) {
		String res = csdkService.getEdgeLog(cmd);
		
		if(res.contains("CsdkService::Failure")) {
			return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}else {
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
	}
	
	@PostMapping("/update_csdk")
	public ResponseEntity<?> updateCsdk(@RequestBody CsdkUpdate updateCmd) {
		String res = csdkService.updateCsdk(updateCmd);
		
		if(!updateCmd.getPattern().equals("NA") && !res.contains(updateCmd.getPattern())) {
			return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
		}else {
			return new ResponseEntity<>(res, HttpStatus.OK);
		}
	}
	
	@GetMapping("/edge_version")
	public String getEdgeVersion() {
		return csdkService.getEdgeVersion();
	}

}

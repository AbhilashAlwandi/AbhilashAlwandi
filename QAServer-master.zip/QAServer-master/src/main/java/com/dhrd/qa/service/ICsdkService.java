package com.dhrd.qa.service;

import org.springframework.http.ResponseEntity;

import com.dhrd.qa.model.CsdkExecuteCommand;
import com.dhrd.qa.model.CsdkUpdate;

public interface ICsdkService {
	
	public String executeCommand(CsdkExecuteCommand cmd);

	public String deleteDeviceCerts(String deviceId);

	public String killCsdkProcess(String device_id);

	public String getEdgeLog(CsdkExecuteCommand cmd);

	public String updateCsdk(CsdkUpdate updateCmd);

	public String getEdgeVersion();

	public void cleanupChromeDriverForTag(String tag);

}

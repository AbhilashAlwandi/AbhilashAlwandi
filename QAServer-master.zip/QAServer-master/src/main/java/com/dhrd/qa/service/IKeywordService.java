package com.dhrd.qa.service;

import java.util.List;

import com.dhrd.qa.model.Component;
import com.dhrd.qa.model.Keyword;

public interface IKeywordService {
	
	public void saveKeyword(Keyword keyword);
	
	public void saveKeyword(List<Keyword> keywordList);

	void deleteKeyword(String name);
	
	public List<String> getAllKeywords();

	public List<Component> getComponentsForKw(String keyword);

	public Keyword getKeywordByName(String keyword);

	public void deleteAllKeywords();
	
}

package com.dhrd.qa.model;

import java.util.List;

import javax.persistence.*;

@Entity
public class Keyword {

	@Id
	private String name;
	private String keywordType;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "keyword", referencedColumnName = "name")
	private List<Component> components;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name.trim();
	}

	public List<Component> getComponents() {
		return components;
	}

	public void setComponents(List<Component> components) {
		this.components = components;
	}

	public String getKeywordType() {
		return keywordType;
	}

	public void setKeywordType(String keywordType) {
		this.keywordType = keywordType;
	}

}

package com.dhrd.qa.notification;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;

/**
 * @author kiran.nayak
 * @description Sends email through Amazon SES
 */
public class AmazonSES extends Notification {

	private final String UTF = "UTF-8";

	private String NOTIFICATION_AWS_REGION;
	private String NOTIFICATION_AWS_ACCESSKEYID;
	private String NOTIFICATION_AWS_SECRETKEY;

	public AmazonSES(String nOTIFICATION_AWS_REGION, String nOTIFICATION_AWS_ACCESSKEYID,
			String nOTIFICATION_AWS_SECRETKEY) {
		super();
		NOTIFICATION_AWS_REGION = nOTIFICATION_AWS_REGION;
		NOTIFICATION_AWS_ACCESSKEYID = nOTIFICATION_AWS_ACCESSKEYID;
		NOTIFICATION_AWS_SECRETKEY = nOTIFICATION_AWS_SECRETKEY;
	}

	@Override
	public void send() {
		final String TEXTBODY = this.getContent();
		String awsRegion = NOTIFICATION_AWS_REGION;
		Properties props = System.getProperties();

		props.setProperty("aws.accessKeyId", NOTIFICATION_AWS_ACCESSKEYID);
		props.setProperty("aws.secretKey", NOTIFICATION_AWS_SECRETKEY);
		System.setProperties(props);
		try {
			AmazonSimpleEmailService client = AmazonSimpleEmailServiceClientBuilder.standard().withRegion(awsRegion)
					.build();
			SendEmailRequest request = new SendEmailRequest()
					.withDestination(new Destination().withToAddresses(getTo()))
					.withMessage(new Message()
							.withBody(new Body().withHtml(new Content().withCharset(UTF).withData(TEXTBODY))
									.withText(new Content().withCharset(UTF).withData(TEXTBODY)))
							.withSubject(new Content().withCharset(UTF).withData(getSubject())))
					.withSource(getFrom());
			client.sendEmail(request);
			System.out.println("Email sent!");
		} catch (Exception ex) {
			throw new RuntimeException("The email was not sent. ", ex);
		}
	}

}

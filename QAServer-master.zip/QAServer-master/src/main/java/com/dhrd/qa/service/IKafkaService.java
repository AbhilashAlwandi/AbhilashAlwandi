package com.dhrd.qa.service;

import com.dhrd.qa.model.KafkaModel;
import com.dhrd.qa.model.KafkaRequest;

public interface IKafkaService {

	public KafkaModel startConsumer(KafkaRequest request);

	public void deleteConsumer(long id);

	public KafkaModel getKafkaRecordsForConsumer(long id);

}

package com.dhrd.qa.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dhrd.qa.model.KafkaModel;

/**
 * 
 * @author kiran.nayak
 *
 */
public class KafkaConsumerRecordsHolder {

	private static Long latest_id = 1L;

	private static Map<Long, KafkaModel> kafkaConsumerRecordsMap = new HashMap<>();
	
	public static Map<Long, KafkaModel> getKafkaConsumerMap() {
		return kafkaConsumerRecordsMap;
	}

	public static synchronized void updateConsumer(KafkaModel model) {
		kafkaConsumerRecordsMap.put(model.getId(), model);
	}

	public static synchronized KafkaModel getRecordsForConsumer(Long id) {
		return kafkaConsumerRecordsMap.get(id);
	}

	public static synchronized void deleteRecordsForConsumer(Long id) {
		kafkaConsumerRecordsMap.remove(id);
	}

	public static synchronized KafkaModel createNewConsumerRecordsHolder() {
		KafkaModel obj = new KafkaModel();
		obj.setId(latest_id++);
		kafkaConsumerRecordsMap.put(obj.getId(), obj);
		return obj;
	}

	public static List<Long> getInactiveConsumers(Long timediff) {
		List<Long> inactiveConsumers = new ArrayList<>();
		for (Map.Entry<Long, KafkaModel> entry : kafkaConsumerRecordsMap.entrySet()) {
			KafkaModel model = entry.getValue();
			Long createdTs = model.getCreatedTs();
			long diff = System.currentTimeMillis() - createdTs;
			if (diff > timediff) {
				inactiveConsumers.add(model.getId());
			}
		}
		return inactiveConsumers;
	}

}

package com.dhrd.qa;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.dhrd.qa.model.TestUtilityService;
import com.dhrd.qa.service.IKafkaService;
import com.dhrd.qa.utilities.ConfigProperties;
import com.dhrd.qa.utilities.KafkaConsumerRecordsHolder;
import com.dhrd.qa.utilities.RemoteServer;

import io.swagger.models.Contact;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.VendorExtension;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableScheduling
@EnableSwagger2
public class QaApplication {

	@Autowired
	IKafkaService kafkaService;

	@Autowired
	TestUtilityService testUtilityService;

	public static void main(String[] args) {
		SpringApplication.run(QaApplication.class, args);
	}

	// https://stackoverflow.com/questions/30887822/spring-cron-vs-normal-cron
	@Scheduled(cron = "0 0 */1 * * *")
	public void cleanupInactiveConsumers() {
		System.out.println("Cleaning up inactive consumers at " + Calendar.getInstance().getTime());

		// Identify id's which are older than 24 hrs
		List<Long> ids = KafkaConsumerRecordsHolder.getInactiveConsumers(24 * 3600 * 1000L);

		System.out.println(KafkaConsumerRecordsHolder.getKafkaConsumerMap());

		// Delete them
		for (int i = 0; i < ids.size(); i++) {
			kafkaService.deleteConsumer(ids.get(i));
		}
	}

	@Scheduled(cron = "0 0 12 1 * *")
	public void cleanupReportServerFiles() {
		System.out.println("Cleaning up report server files at " + Calendar.getInstance().getTime());
		int noOfDaysReportsToBeKeptForDays = 30 * 6;

		String reportServer = testUtilityService.getReportServer();

		String reportServerUser = testUtilityService.getReportServerUser();

		String reportServerPemFile = testUtilityService.getReportServerPemFile();

		String reportServerBasePath = testUtilityService.getReportServerBasePath();

		String cmd = "cd " + reportServerBasePath + " && find . -mindepth 1 -mtime +" + noOfDaysReportsToBeKeptForDays
				+ " -delete";
		RemoteServer server = new RemoteServer();
		server.executeCommand(reportServer, reportServerUser, reportServerPemFile, cmd);
	}

	@Bean
	public Docket swaggerConfiguration() {
		return new Docket(DocumentationType.SWAGGER_2).apiInfo(getApiDetails());
	}

	private ApiInfo getApiDetails() {
		Collection<VendorExtension> vendorExtension = new ArrayList<>();
		return new ApiInfo("QA Server API", "Helps & enables engineers to develop automated tests faster", "1.0",
				"http://danaherdigital.com",
				new springfox.documentation.service.Contact("Kiran Nayak", "http://www.danaherdigital.com",
						"kiran.nayak@danaherdigital.com"),
				"http://danaherdigital.com", "http://danaherdigital.com", vendorExtension);

	}

}

package com.dhrd.qa.model;

import java.util.List;

public class TestMetadataResponseHolder {

	private List<String> testGroup;
	private List<String> modules;
	private List<String> keywordType;
	private List<String> elementType;
	private List<String> kwList;
	private List<String> identifierList;

	public List<String> getTestGroup() {
		return testGroup;
	}

	public void setTestGroup(List<String> testGroup) {
		this.testGroup = testGroup;
	}

	public List<String> getModules() {
		return modules;
	}

	public void setModules(List<String> modules) {
		this.modules = modules;
	}

	public List<String> getKeywordType() {
		return keywordType;
	}

	public void setKeywordType(List<String> keywordType) {
		this.keywordType = keywordType;
	}

	public List<String> getElementType() {
		return elementType;
	}

	public void setElementType(List<String> elementType) {
		this.elementType = elementType;
	}

	public List<String> getKwList() {
		return kwList;
	}

	public void setKwList(List<String> kwList) {
		this.kwList = kwList;
	}

	public List<String> getIdentifierList() {
		return identifierList;
	}

	public void setIdentifierList(List<String> identifierList) {
		this.identifierList = identifierList;
	}

}

package com.dhrd.qa.model;

import java.util.List;
import java.util.Map;

public class CsdkExecuteCommand {

	String deviceId, pattern, timeout;

	List<Map<String, String>> input;

	boolean background;

	public boolean getBackground() {
		return background;
	}

	public void setBackground(boolean background) {
		this.background = background;
	}

	public List<Map<String, String>> getInput() {
		return input;
	}

	public void setInput(List<Map<String, String>> input) {
		this.input = input;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getTimeout() {
		return timeout;
	}

	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}

}

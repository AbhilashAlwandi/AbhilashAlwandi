package com.dhrd.qa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dhrd.qa.model.IngestionRequest;
import com.dhrd.qa.service.IIngestionService;
import com.dhrd.qa.service.IKeywordService;

@RestController
@RequestMapping("/ingest")
public class IngestionController {
	
	@Autowired
	IIngestionService ingestionService;
	
	@PostMapping("/master-certs")
	public void ingestData(@RequestBody IngestionRequest request) {
		
		ingestionService.ingestDataThroughMasterCerts(request);
		
	}

}

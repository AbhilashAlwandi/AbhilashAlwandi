package com.dhrd.qa.service;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dhrd.qa.model.Component;
import com.dhrd.qa.model.Keyword;
import com.dhrd.qa.repositories.KeywordRepository;

@Service
public class KeywordService implements IKeywordService {

	@Autowired
	private KeywordRepository kwRepo;

	@Override
	public void saveKeyword(Keyword keyword) {
		kwRepo.save(keyword);
	}

	@Override
	public void deleteKeyword(String name) {
		kwRepo.deleteById(name);
	}

	@Override
	public List<String> getAllKeywords() {
		List<Keyword> kwList = kwRepo.findAll();
		List<String> kwListToReturn = new LinkedList<>();
		for (int i = 0; i < kwList.size(); i++) {
			kwListToReturn.add(kwList.get(i).getName().trim());
		}
		Collections.sort(kwListToReturn);
		return kwListToReturn;
	}

	@Override
	public List<Component> getComponentsForKw(String keyword) {
		Keyword kw = kwRepo.getOne(keyword);
		return kw.getComponents();
	}

	@Override
	public Keyword getKeywordByName(String keyword) {
		return kwRepo.findById(keyword).get();
	}

	@Override
	public void saveKeyword(List<Keyword> keywordList) {
		kwRepo.saveAll(keywordList);
	}

	@Override
	public void deleteAllKeywords() {
		kwRepo.deleteAll();
	}

}

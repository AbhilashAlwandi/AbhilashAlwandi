package com.dhrd.qa.model;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dhrd.qa.utilities.RemoteServer;

@Service
public class TestUtilityService implements ITestUtilityService {

	@Value("${csdk.host}")
	private String host;

	@Value("${csdk.user}")
	private String user;

	@Value("${csdk.pemfile}")
	private String pemfile;

	@Value("${csdk.automation.certs.path}")
	private String automationCertsPath;

	@Value("${csdk.executeCommandPath}")
	private String executeCommandPath;

	@Value("${csdk.keyword.find}")
	private String find;

	@Value("${report.server}")
	private String reportServer;

	@Value("${report.server.user}")
	private String reportServerUser;

	@Value("${report.server.pemfile}")
	private String reportServerPemFile;

	@Value("${report.server.basePath}")
	private String reportServerBasePath;

	private RemoteServer server = new RemoteServer();

	@Override
	public DmAuthToken getAuthTokenForDm(DmAuthToken obj) throws Exception {
		String command = null;
		command = "echo '" + obj.getInput() + "'" + " | openssl aes-256-cbc -k " + obj.getPassword()
				+ " -base64 2>/dev/null";
		String result = server.executeCommand(host, user, pemfile, command).trim();
		obj.setToken(result);
		return obj;
	}

	@Override
	public String uploadReports(MultipartFile file, String env, String tenant) {
		String fileUploadStatus = "File upload failed";
		try {
			String todaysDate = java.time.LocalDate.now().toString();
			String reportServerFolderPath = reportServerBasePath + "/" + env + "/" + tenant + "/" + todaysDate;
			String filePath = "resources/externalFiles/" + file.getOriginalFilename();
			byte[] fileContents = file.getBytes();
			FileOutputStream fos = new FileOutputStream(filePath);
			fos.write(fileContents);
			fos.close();
			server.executeCommand(reportServer, reportServerUser, reportServerPemFile,
					"mkdir -p " + reportServerFolderPath);
			server.uploadFile(filePath, reportServerFolderPath, reportServerUser, reportServer, reportServerPemFile);
		} catch (IllegalStateException e) {
			e.printStackTrace();
			return fileUploadStatus + "\n" + e.getStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			return fileUploadStatus + "\n" + e.getStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			return fileUploadStatus + "\n" + e.getStackTrace();
		}
		return "Reports uploaded successfully";
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPemfile() {
		return pemfile;
	}

	public void setPemfile(String pemfile) {
		this.pemfile = pemfile;
	}

	public String getAutomationCertsPath() {
		return automationCertsPath;
	}

	public void setAutomationCertsPath(String automationCertsPath) {
		this.automationCertsPath = automationCertsPath;
	}

	public String getExecuteCommandPath() {
		return executeCommandPath;
	}

	public void setExecuteCommandPath(String executeCommandPath) {
		this.executeCommandPath = executeCommandPath;
	}

	public String getFind() {
		return find;
	}

	public void setFind(String find) {
		this.find = find;
	}

	public String getReportServer() {
		return reportServer;
	}

	public void setReportServer(String reportServer) {
		this.reportServer = reportServer;
	}

	public String getReportServerUser() {
		return reportServerUser;
	}

	public void setReportServerUser(String reportServerUser) {
		this.reportServerUser = reportServerUser;
	}

	public String getReportServerPemFile() {
		return reportServerPemFile;
	}

	public void setReportServerPemFile(String reportServerPemFile) {
		this.reportServerPemFile = reportServerPemFile;
	}

	public String getReportServerBasePath() {
		return reportServerBasePath;
	}

	public void setReportServerBasePath(String reportServerBasePath) {
		this.reportServerBasePath = reportServerBasePath;
	}

	public RemoteServer getServer() {
		return server;
	}

	public void setServer(RemoteServer server) {
		this.server = server;
	}

}

package com.dhrd.qa.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.dhrd.qa.notification.NotificationUtility;

@Service
public class NotificationService implements INotificationService {

	@Value("${notification.from}")
	private String NOTIFICATION_FROM;

	@Value("${notification.aws.region}")
	private String NOTIFICATION_AWS_REGION;

	@Value("${notification.aws.accessKeyId}")
	private String NOTIFICATION_AWS_ACCESSKEYID;

	@Value("${notification.aws.secretKey}")
	private String NOTIFICATION_AWS_SECRETKEY;

	@Override
	public void sendNotification(String to, String subject, String body) {
		NotificationUtility.sendEmail(NOTIFICATION_FROM, to, subject, body, NOTIFICATION_AWS_REGION,
				NOTIFICATION_AWS_ACCESSKEYID, NOTIFICATION_AWS_SECRETKEY);
	}

}

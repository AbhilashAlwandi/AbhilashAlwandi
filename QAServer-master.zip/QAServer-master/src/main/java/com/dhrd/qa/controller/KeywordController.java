package com.dhrd.qa.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dhrd.qa.model.Component;
import com.dhrd.qa.model.Keyword;
import com.dhrd.qa.service.IKeywordService;

@RestController
@RequestMapping("/keyword")
public class KeywordController {

	@Autowired
	IKeywordService keywordService;

	@PostMapping("/create")
	public String createKeyword(@RequestBody Keyword keyword, HttpServletResponse response) {
		try {
			keywordService.saveKeyword(keyword);
			return "Successfully added keyword " + keyword.getName();
		} catch (Throwable t) {
			response.setStatus(502);
			t.printStackTrace();
			return "Failure in adding the keyword: \n\n" + t.getMessage();
		}
	}
	
	@PostMapping("/create-list")
	public void createKeywordList(@RequestBody List<Keyword> keywordList, HttpServletResponse response) {
		try {
			keywordService.saveKeyword(keywordList);
		} catch (Throwable t) {
			response.setStatus(502);
			t.printStackTrace();
		}
	}

	@DeleteMapping("/delete/{name}")
	public String deleteKeyword(@PathVariable String name, HttpServletResponse response) {
		try {
			keywordService.deleteKeyword(name);
			response.setStatus(200);
			return "Successfully deleted keyword " + name;
		} catch (Throwable t) {
			response.setStatus(502);
			t.printStackTrace();
			return "Failure in deleting the keyword: \n\n" + t.getMessage();
		}
	}

	@GetMapping("/get-all")
	public List<String> getKeywords() {
		List<String> keywords = keywordService.getAllKeywords();
		return keywords;
	}

	@GetMapping("/{keyword}/get-components")
	public List<Component> getComponentForKeyword(@PathVariable String keyword) {
		return keywordService.getComponentsForKw(keyword);
	}
	
	@GetMapping("/{keyword}/get")
	public Keyword getKeywordByName(@PathVariable String keyword) {
		return keywordService.getKeywordByName(keyword);
	}
	
	@DeleteMapping("/delete-all")
	public void deleteAllKws() {
		keywordService.deleteAllKeywords();
	}
	
}

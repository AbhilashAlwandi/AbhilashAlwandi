package com.dhrd.qa.utilities;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:application.properties")
public class ConfigProperties {

    @Autowired
    private Environment env;
    
    @Value("${notification.from}")
    private String varTest;

    public String getConfigValue(String configKey){
    	System.out.println(varTest);
        return varTest;
    }
}

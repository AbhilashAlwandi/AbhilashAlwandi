package com.dhrd.qa.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.springframework.stereotype.Service;

import com.dhrd.qa.model.KafkaModel;
import com.dhrd.qa.model.KafkaRequest;
import com.dhrd.qa.utilities.KafkaConsumerClient;
import com.dhrd.qa.utilities.KafkaConsumerRecordsHolder;

@Service
public class KafkaService implements IKafkaService {

	final String RESOURCES_KAFKA_PATH = "resources/kafka/";

	private static Map<Long, KafkaConsumerClient> consumerInstanceMap = new HashMap<>();

	@Override
	public KafkaModel startConsumer(KafkaRequest request) {

		KafkaModel model = new KafkaModel();
		model = KafkaConsumerRecordsHolder.createNewConsumerRecordsHolder();

		String topic = request.getTopic();
		String env = request.getEnv();

		String envFolderPath = RESOURCES_KAFKA_PATH + env;

		try (InputStream input = new FileInputStream(envFolderPath + "/client-ssl-auth.properties")) {

			Properties prop = new Properties();

			// load a properties file
			prop.load(input);

			String bootstrapServer = prop.getProperty("bootstrap.servers");
			String sslTrustStoreLocation = prop.getProperty("ssl.truststore.location");
			String sslTrustStorePass = prop.getProperty("ssl.truststore.password");
			String sslPasswordConfig = prop.getProperty("ssl.keystore.location");
			String sslPasswordPass = prop.getProperty("ssl.keystore.password");
			
			KafkaConsumerClient consumer=new KafkaConsumerClient(model.getId(),bootstrapServer, sslTrustStoreLocation, sslTrustStorePass, sslPasswordConfig,
					sslPasswordPass, topic);
			consumerInstanceMap.put(model.getId(), consumer);
			consumer.start();
		} catch (IOException ex) {
			System.out.println("Exception found " + ex.toString());
			ex.printStackTrace();
		}

		return model;
	}

	@Override
	public void deleteConsumer(long id) {
		consumerInstanceMap.get(id).setRunThread(false);
		while(!consumerInstanceMap.get(id).isThreadExecutionComplete()) {
			System.out.println("For id "+id+" waiting for the thread to complete execution");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		consumerInstanceMap.get(id).shutDownConsumer();
		consumerInstanceMap.remove(id);
		KafkaConsumerRecordsHolder.deleteRecordsForConsumer(id);
	}

	@Override
	public KafkaModel getKafkaRecordsForConsumer(long id) {
		return KafkaConsumerRecordsHolder.getRecordsForConsumer(id);
	}

}

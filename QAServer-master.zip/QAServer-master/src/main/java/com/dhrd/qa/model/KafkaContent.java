package com.dhrd.qa.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

public class KafkaContent {

	private String value, key;
	long partition;
	long offset;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String content) {
		this.value = content;
	}

	public long getPartition() {
		return partition;
	}

	public void setPartition(long partition) {
		this.partition = partition;
	}

	public long getOffset() {
		return offset;
	}

	public void setOffset(long offset) {
		this.offset = offset;
	}

	@Override
	public String toString() {
		return "KafkaContent [value=" + value + ", key=" + key + ", partition=" + partition + ", offset=" + offset
				+ "]";
	}

}

package com.dhrd.qa.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dhrd.qa.model.CsdkExecuteCommand;
import com.dhrd.qa.model.CsdkUpdate;
import com.dhrd.qa.utilities.RemoteServer;

@Service
public class CsdkService implements ICsdkService {

	@Value("${csdk.host}")
	private String host;

	@Value("${csdk.user}")
	private String user;

	@Value("${csdk.pemfile}")
	private String pemfile;

	@Value("${csdk.automation.certs.path}")
	private String automationCertsPath;

	@Value("${csdk.executeCommandPath}")
	private String executeCommandPath;

	@Value("${csdk.base}")
	private String csdkBase;

	@Value("${csdk.keyword.find}")
	private String find;

	@Value("${csdk.keyword.replace}")
	private String replace;

	private RemoteServer server = new RemoteServer();

	@Override
	public String executeCommand(CsdkExecuteCommand cmd) {
		String result = null;
		List<Map<String, String>> userCommand = cmd.getInput();

		String cmdStr = "'";

		for (int i = 0; i < userCommand.size(); i++) {
			if (i != userCommand.size() - 1)
				cmdStr = cmdStr + userCommand.get(i).get("value").trim() + "\\n";
			else
				cmdStr = cmdStr + userCommand.get(i).get("value").trim();
		}

		cmdStr += "'";

		cmdStr = findAndReplaceKeywords(cmdStr);

		String command = executeCommandPath + " " + cmdStr + " " + cmd.getDeviceId() + " " + cmd.getBackground();
		System.out.println("The command to be executed is : " + command);
		result = server.executeCommand(host, user, pemfile, command);

		result = getEdgeLogContent(cmd, result);

		return result;

	}

	private String findAndReplaceKeywords(String cmdStr) {

		String[] findArr = find.split(",");
		String[] replaceArr = replace.split(",");

		for (int i = 0; i < findArr.length; i++) {
			cmdStr = cmdStr.replace(findArr[i].trim(), replaceArr[i].trim());
		}

		return cmdStr;

	}

	@Override
	public String deleteDeviceCerts(String deviceId) {

		String result = server.executeCommand(host, user, pemfile, "rm -rf " + automationCertsPath + "/" + deviceId);
		return result;
	}

	@Override
	public String killCsdkProcess(String device_id) {
		String result = server.executeCommand(host, user, pemfile, "pkill -f " + device_id + " -9");
		return result;
	}

	private String getEdgeLogContent(CsdkExecuteCommand cmd, String existingValue) {
		String result = existingValue;
		String pattern = cmd.getPattern();
		if (!cmd.getPattern().equals("NA")) {
			long timeout = Long.valueOf(cmd.getTimeout()) * 1000;
			long polling_time = 1000;
			long elapsed_time = 0;

			String commandToGrepEdgeLog = "grep \"" + pattern + "\" " + automationCertsPath + "/"
					+ cmd.getDeviceId().trim() + "/edge.log";

			while (elapsed_time <= timeout) {
				elapsed_time += polling_time;
				String logMatch = server.executeCommand(host, user, pemfile, commandToGrepEdgeLog).trim();
				System.out.println(logMatch);
				if (logMatch.trim().length() > 0) {
					break;
				}
			}

			if (elapsed_time >= timeout) {
				result += "CsdkService::Failure ::Pattern not found within configured timeout " + timeout;
				killCsdkProcess(cmd.getDeviceId());
			}
		}

		String commandToGetEdgeLogContent = "cat " + automationCertsPath + "/" + cmd.getDeviceId().trim() + "/edge.log";
		String edgeLogs = server.executeCommand(host, user, pemfile, commandToGetEdgeLogContent).trim();

		result += "EDGE LOG\n\n" + edgeLogs;
		return result;
	}

	@Override
	public String getEdgeLog(CsdkExecuteCommand cmd) {
		return getEdgeLogContent(cmd, "");
	}

	@Override
	public String updateCsdk(CsdkUpdate updateCmd) {
		StringBuilder res = new StringBuilder("");
		res.append("Making sure that there are no other csdk processes running");
		String result = server.executeCommand(host, user, pemfile, "pkill -f dhrdconnect_demo -9");
		res.append("\nResult of killing the processes \n" + result);

		res.append("Resetting all local changes");
		result = server.executeCommand(host, user, pemfile, "cd " + csdkBase + " && git reset --hard");
		res.append("\nResult of resetting local changes:\n " + result);

		res.append("Fetching all tags and branches");
		result = server.executeCommand(host, user, pemfile,
				"cd " + csdkBase + " && git fetch --tags --force --progress");
		res.append("\nResult of fetching all tags and branches:\n " + result);

		res.append("Changing the branch to " + updateCmd.getBranch().trim());
		result = server.executeCommand(host, user, pemfile,
				"cd " + csdkBase + " && git checkout " + updateCmd.getBranch().trim());
		res.append("\nResult of changing the branch:\n " + result);

		res.append("Pulling in changes from git");
		result = server.executeCommand(host, user, pemfile,
				"cd " + csdkBase + " && git pull origin " + updateCmd.getBranch().trim());
		res.append("\nResult of pulling in changes:\n " + result);

		if (!updateCmd.getCommit().trim().equals("latest")) {
			res.append("\nChanging the commit point to:" + updateCmd.getCommit().trim());
			result = server.executeCommand(host, user, pemfile,
					"cd " + csdkBase + " && git checkout -f " + updateCmd.getCommit().trim());
			res.append("\nResult of pulling in changes:\n " + result);
		}
		
		result = server.executeCommand(host, user, pemfile,
				"cd " + csdkBase + " &&  git log -1");
		res.append("\nThe current git commit point is at :\n " + result);
		
		res.append("Configuring edge sdk");
		result = server.executeCommand(host, user, pemfile,
				"cd " + csdkBase + " && ./configure --disable-tests");
		res.append("\nResult of configuring edge sdk:\n " + result);
		
		res.append("make clean");
		result = server.executeCommand(host, user, pemfile,
				"cd " + csdkBase + " && make clean");
		res.append("\nMake clean result:\n " + result);
		
		res.append("make");
		result = server.executeCommand(host, user, pemfile,
				"cd " + csdkBase + " && make");
		res.append("\nMake result:\n " + result);
		
		result = getEdgeVersion();
		res.append("\nCSDK version:\n " + result);

		return res.toString();
	}

	@Override
	public String getEdgeVersion() {
		CsdkExecuteCommand cmd=new CsdkExecuteCommand();
		cmd.setBackground(false);
		cmd.setDeviceId("Dummy");
		List<Map<String, String>> listOfMap=new ArrayList<>();
		Map<String, String> map=new HashMap<>();
		map.put("option", "Do you want to do provisioning - No");
		map.put("value", "2");
		listOfMap.add(map);
		cmd.setInput(listOfMap);
		cmd.setPattern("NA");
		cmd.setTimeout("0");
		
		String version=executeCommand(cmd);
		
		return version;
	}

	@Override
	public void cleanupChromeDriverForTag(String tag) {
		killCsdkProcess(tag);
	}
	

}

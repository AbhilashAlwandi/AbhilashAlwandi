package com.dhrd.qa.utilities;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import com.jcraft.jsch.*;

public class RemoteServer {

	Session session;
	Channel channel;
	ChannelSftp channelSftp;

	public String executeCommand(String host, String remoteUser, String pemFile, String cmd) {
		System.out.println("The command running on " + remoteUser + "@" + host + " is : " + cmd);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {

			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			jsch.addIdentity(pemFile);
			Session session = jsch.getSession(remoteUser, host, 22);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");
			Channel channel1 = session.openChannel("exec");
			baos = new ByteArrayOutputStream();
			channel1.setOutputStream(baos);
			((ChannelExec) channel1).setCommand(cmd);
			// ((ChannelExec) channel1).setCommand("sleep 5");
			channel1.setInputStream(null);
			((ChannelExec) channel1).setErrStream(System.err);
			channel1.connect();

			while (true) {
				if (channel1.isClosed()) {
					System.out.println("exit-status: " + channel1.getExitStatus());
					break;
				}
				try {
					Thread.sleep(1000);
					System.out.println("cmd execution in progress ... ");
				} catch (Exception ee) {
					return null;
				}

			}

			channel1.disconnect();
			session.disconnect();
			System.out.println("Command execution done");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return new String(baos.toByteArray());

	}

	public boolean uploadFile(String source, String dest, String remoteUser, String host, String pemFile)
			throws Exception {
		System.out.println("Copying file from " + source + " to " + dest);

		try {
			JSch jsch = new JSch();
			jsch.addIdentity(pemFile);
			session = jsch.getSession(remoteUser, host, 22);
			session.setTimeout(60000);
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect(); // Create SFTP Session
			channel = session.openChannel("sftp"); // Open SFTP Channel
			channel.connect();
			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(dest); // Change Directory on SFTP Server

			recursiveFolderUpload(source, dest);

		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		} finally {
			if (channelSftp != null)
				channelSftp.disconnect();
			if (channel != null)
				channel.disconnect();
			if (session != null)
				session.disconnect();

		}
		return true;
	}

	private void recursiveFolderUpload(String sourcePath, String destinationPath)
			throws SftpException, FileNotFoundException {
		final String TAG = "recursiveFolderUpload:: ";

		File sourceFile = new File(sourcePath);
		String sourceFileName = sourceFile.getName();

		System.out.println("The destination for " + sourceFileName + " is " + destinationPath);
		System.out.println(TAG + "Sourcefile is : " + sourceFile);
		System.out.println(TAG + "Sourcefile absolute path is : " + sourceFile.getAbsolutePath());
		System.out.println(TAG + "Sourcefile path is : " + sourceFile.getPath());

		if (sourceFile.isFile()) {
			System.out.println(TAG + sourceFileName + " is a file and attempting to copy it to " + destinationPath);

			// copy if it is a file
			channelSftp.cd(destinationPath);
			if (!sourceFile.getName().startsWith("."))
				channelSftp.put(new FileInputStream(sourceFile), sourceFile.getName(), ChannelSftp.OVERWRITE);

		} else {
//			System.out
//					.println(TAG + sourceFileName + " is a directory and attempting to copy it to " + destinationPath);
			File[] files = sourceFile.listFiles();
//			System.out.println("The directory consists of the following fiels:");
			for (int i = 0; i < files.length; i++) {
//				System.out.println(files[i].getAbsolutePath() + " " + files[i].getPath());
			}

			if (files != null && !sourceFile.getName().startsWith(".")) {

				channelSftp.cd(destinationPath);
				SftpATTRS attrs = null;

				// check if the directory is already existing
				try {
					attrs = channelSftp.stat(destinationPath + "/" + sourceFile.getName());
//					System.out.println(destinationPath + "/" + sourceFile.getName() + " found");
				} catch (Exception e) {
					System.out.println(destinationPath + "/" + sourceFile.getName() + " not found");
				}

				// else create a directory
				if (attrs != null) {
//					System.out.println("Directory exists IsDir=" + attrs.isDir());
				} else {
//					System.out.println("Creating dir " + sourceFile.getName());
					channelSftp.mkdir(sourceFile.getName());
				}

				for (File f : files) {
					recursiveFolderUpload(f.getAbsolutePath(), destinationPath + "/" + sourceFile.getName());
				}

			}
		}

	}

}

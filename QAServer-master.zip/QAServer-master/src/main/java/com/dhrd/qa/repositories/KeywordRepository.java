package com.dhrd.qa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dhrd.qa.model.Keyword;

public interface KeywordRepository extends JpaRepository<Keyword, String> {

}

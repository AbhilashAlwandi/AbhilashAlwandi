package com.dhrd.qa.model;

import org.springframework.web.multipart.MultipartFile;

public interface ITestUtilityService {
	
	public DmAuthToken getAuthTokenForDm(DmAuthToken obj) throws Exception;

	public String uploadReports(MultipartFile file, String env, String tenant);

}

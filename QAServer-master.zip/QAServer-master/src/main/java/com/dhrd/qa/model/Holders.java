package com.dhrd.qa.model;

public class Holders {

	public enum TestGroup {
		SMOKE, SANITY, REGRESSION, SYNTHETIC;
	}

	public enum KeywordType {
		API;
	}

}

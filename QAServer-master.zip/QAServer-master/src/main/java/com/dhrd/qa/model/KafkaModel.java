package com.dhrd.qa.model;

import java.util.ArrayList;
import java.util.List;

public class KafkaModel {

	private Long id;
	private long createdTs;

	private List<KafkaContent> kafkaContent=new ArrayList<>();
	
	public KafkaModel() {
		createdTs=System.currentTimeMillis();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<KafkaContent> getKafkaContent() {
		return kafkaContent;
	}

	public void setKafkaContent(List<KafkaContent> kafkaContent) {
		this.kafkaContent = kafkaContent;
	}

	public long getCreatedTs() {
		return createdTs;
	}
	

}

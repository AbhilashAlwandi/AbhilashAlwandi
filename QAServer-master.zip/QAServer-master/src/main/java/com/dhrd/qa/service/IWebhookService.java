package com.dhrd.qa.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.dhrd.qa.model.Webhook;
import com.dhrd.qa.model.WebhookContent;

public interface IWebhookService {

	public Webhook register();

	public String store(String requestHeader, String content, Long id);

	public Page<WebhookContent> getWebhookContent(Long uuid, Pageable pageable);

	public void delete(Long uuid);

	Webhook register(Webhook webhook1);


}

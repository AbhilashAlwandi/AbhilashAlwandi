package com.dhrd.qa.utilities;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dhrd.qa.model.KafkaContent;
import com.dhrd.qa.model.KafkaModel;

import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerConfig;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

/**
 * @author kiran.nayak
 * @description Java client which consumes data from the topic
 *
 */
public class KafkaConsumerClient extends Thread {

	private KafkaConsumer<String, String> consumer;
	private Long consumerId;
	private boolean runThread = true;
	private boolean threadExecutionComplete = false;

	String bootstrapServer;
	String sslTrustStoreLocation;
	String sslTrustStorePass;
	String sslPasswordConfig;
	String sslPasswordPass;
	String topic;

	public KafkaConsumerClient(Long consumerId, String bootstrapServer, String sslTrustStoreLocation,
			String sslTrustStorePass, String sslPasswordConfig, String sslPasswordPass, String topic) {
		super();
		this.consumerId = consumerId;
		this.bootstrapServer = bootstrapServer;
		this.sslTrustStoreLocation = sslTrustStoreLocation;
		this.sslTrustStorePass = sslTrustStorePass;
		this.sslPasswordConfig = sslPasswordConfig;
		this.sslPasswordPass = sslPasswordPass;
		this.topic = topic;
	}

	public KafkaConsumerClient(String bootstrapServer, String sslTrustStoreLocation, String sslTrustStorePass,
			String sslPasswordConfig, String sslPasswordPass, String topic) {
	}

	private void createConsumer() {
		// Creating consumer properties
		Properties properties = new Properties();

		String bootstrapServers = bootstrapServer;
		String grp_id = UUID.randomUUID().toString();

		// Authentication
		properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
		properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslTrustStoreLocation);
		properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, sslTrustStorePass);

		// configure the following three settings for SSL Authentication
		properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, sslPasswordConfig);
		properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, sslPasswordPass);
		properties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, sslPasswordPass);

		properties.put(ProducerConfig.ACKS_CONFIG, "all");
		properties.put(ProducerConfig.RETRIES_CONFIG, 0);

		properties.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		properties.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		properties.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG, grp_id);
		properties.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");

		properties.put("connections.max.idle.ms", 180000);
		properties.put("request.timeout.ms", 30000);

		// creating consumer
		consumer = new KafkaConsumer<String, String>(properties);
		// Subscribing
		consumer.subscribe(Arrays.asList(topic));
		// polling
		while (runThread) {
			ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
			for (ConsumerRecord<String, String> record : records) {
				KafkaModel model = KafkaConsumerRecordsHolder.getRecordsForConsumer(consumerId);
				List<KafkaContent> kafkaContent = model.getKafkaContent();

				KafkaContent contentToAdd = new KafkaContent();
				contentToAdd.setValue(record.value());
				contentToAdd.setKey(record.key());
				contentToAdd.setOffset(record.offset());
				contentToAdd.setPartition(record.partition());
				kafkaContent.add(contentToAdd);
				
				model.setKafkaContent(kafkaContent);

				KafkaConsumerRecordsHolder.updateConsumer(model);
				
				System.out.println("Consumed : "+contentToAdd);
			}

		}
		
		threadExecutionComplete=true;
	}

	@Override
	public void run() {
		createConsumer();
	}

	public void shutDownConsumer() {
		consumer.close();
	}

	public KafkaConsumer<String, String> getConsumer() {
		return consumer;
	}

	public void setConsumer(KafkaConsumer<String, String> consumer) {
		this.consumer = consumer;
	}

	public long getConsumerId() {
		return consumerId;
	}

	public void setConsumerId(long consumerId) {
		this.consumerId = consumerId;
	}

	public boolean isRunThread() {
		return runThread;
	}

	public void setRunThread(boolean runThread) {
		this.runThread = runThread;
	}

	public boolean isThreadExecutionComplete() {
		return threadExecutionComplete;
	}

	public void setThreadExecutionComplete(boolean threadExecutionComplete) {
		this.threadExecutionComplete = threadExecutionComplete;
	}
	
	

}

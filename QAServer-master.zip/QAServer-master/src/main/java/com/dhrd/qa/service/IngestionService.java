package com.dhrd.qa.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.stereotype.Service;

import com.dhrd.qa.model.IngestionRequest;
import com.dhrd.qa.utilities.KafkaProducerClient;

@Service
public class IngestionService implements IIngestionService {

	final String RESOURCES_KAFKA_PATH = "resources/kafka/";

	@Override
	public void ingestDataThroughMasterCerts(IngestionRequest req) {
		String payload = req.getPayload();
		String topic = req.getTopic();
		String env = req.getEnvironment();

		String envFolderPath = RESOURCES_KAFKA_PATH + env;

		System.out.println("Payload " + payload + " topic " + topic + " env " + env);

		KafkaProducerClient client = new KafkaProducerClient();

		try (InputStream input = new FileInputStream(envFolderPath + "/client-ssl-auth.properties")) {

			Properties prop = new Properties();

			// load a properties file
			prop.load(input);

			String bootstrapServer = prop.getProperty("bootstrap.servers");
			String sslTrustStoreLocation = prop.getProperty("ssl.truststore.location");
			String sslTrustStorePass = prop.getProperty("ssl.truststore.password");
			String sslPasswordConfig = prop.getProperty("ssl.keystore.location");
			String sslPasswordPass = prop.getProperty("ssl.keystore.password");

			client.sendEvents(bootstrapServer, sslTrustStoreLocation, sslTrustStorePass, sslPasswordConfig,
					sslPasswordPass, topic, payload);

		} catch (IOException ex) {
			System.out.println("Exception found " + ex.toString());
			ex.printStackTrace();
		}

	}

}

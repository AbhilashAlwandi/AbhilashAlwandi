package com.dhrd.qa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.dhrd.qa.model.TestMetadataRepoHolder;

public interface TestMetadataRepo extends JpaRepository<TestMetadataRepoHolder, Long> {

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update TestMetadataRepoHolder t set t.value=:value where t.identifier=:identifier")
	public int updateValue(@Param("identifier") String identifier, @Param("value") String value);

}

package com.dhrd.qa.service;

import java.util.List;

import com.dhrd.qa.model.Component;
import com.dhrd.qa.model.IngestionRequest;
import com.dhrd.qa.model.Keyword;

public interface IIngestionService {
	
	public void ingestDataThroughMasterCerts(IngestionRequest req);
	
}

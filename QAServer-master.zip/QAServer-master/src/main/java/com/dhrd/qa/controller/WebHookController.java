package com.dhrd.qa.controller;

import java.util.Map;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dhrd.qa.model.Test;
import com.dhrd.qa.model.Webhook;
import com.dhrd.qa.model.WebhookContent;
import com.dhrd.qa.service.IWebhookService;

@RestController
@RequestMapping("/webhook")
public class WebHookController {

	@Autowired
	IWebhookService webhookService;

	@GetMapping("/register")
	public Webhook register() {
		return webhookService.register();
	}
	
	@PostMapping("/register")
	public Webhook registerPost(@RequestBody Webhook webhook) {
		return webhookService.register(webhook);
	}

	@RequestMapping("/store/{uuid}")
	public String store(@RequestHeader Map<String, String> headers, @RequestBody String content, @PathVariable Long uuid) {
		return webhookService.store(headers.toString(), content, uuid);
	}
	
	@GetMapping("/get/{uuid}")
	public Page<WebhookContent> getWebhookContent(@PathVariable Long uuid, Pageable pageable) {
		return webhookService.getWebhookContent(uuid, pageable);
	}
	
	@DeleteMapping("/delete/{uuid}")
	public void deleteWebhook(@PathVariable Long uuid) {
		webhookService.delete(uuid);
	}

}

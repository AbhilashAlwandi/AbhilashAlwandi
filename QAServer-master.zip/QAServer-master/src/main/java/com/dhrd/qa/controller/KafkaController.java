package com.dhrd.qa.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dhrd.qa.model.KafkaModel;
import com.dhrd.qa.model.KafkaRequest;
import com.dhrd.qa.service.IKafkaService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/kafka")
public class KafkaController {

	@Autowired
	IKafkaService kafkaService;

	@PostMapping("/consumer/start")
	@ApiOperation(value="Starts a consumer in the backend and returns the consumer identifier", 
	notes="Starts the consumer and returns the id",
	response=KafkaModel.class)
	public KafkaModel startConsumer(@RequestBody KafkaRequest req) {
		return kafkaService.startConsumer(req);
	}

	@DeleteMapping("consumer/delete/{id}")
	@ApiOperation(value="Deletes the consumer in the backend", 
	notes="Deletes the consumer in the backend for given id")
	public void deleteConsumer(@PathVariable Long id) {
		kafkaService.deleteConsumer(id);
	}

	@ApiOperation(value="Gets the consumed records for a given id", 
			notes="Gets the consumed records for a given id",
			response=KafkaModel.class)
	@GetMapping("/consumer/get_content/{id}")
	public KafkaModel getKafkaData(@PathVariable Long id) {
		return kafkaService.getKafkaRecordsForConsumer(id);
	}

}

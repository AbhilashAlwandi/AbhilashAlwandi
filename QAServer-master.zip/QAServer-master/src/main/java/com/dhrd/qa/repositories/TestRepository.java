package com.dhrd.qa.repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.dhrd.qa.model.Test;

public interface TestRepository extends JpaRepository<Test, Long>, JpaSpecificationExecutor<Test> {

	@Query("select t from Test t where t.moduleName=?1 order by id desc")
	Page<Test> getTestsForModule(String module, Pageable pageable);

	@Query("select distinct(t.moduleName) from Test t")
	List<String> getListOfModules();

}

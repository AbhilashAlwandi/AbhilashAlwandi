package com.dhrd.qa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dhrd.qa.model.Test;
import com.dhrd.qa.model.TestMetadataResponseHolder;
import com.dhrd.qa.service.ITestService;

@RestController
@RequestMapping("/test")
public class TestController {

	@Autowired
	ITestService testService;

	@PostMapping("/create")
	public void create(@RequestBody Test test) {
		testService.createTest(test);
	}

	@GetMapping("/metadata")
	public TestMetadataResponseHolder getTestMetadata() {
		return testService.getTestMetaData();
	}
	
	@PutMapping("/metadata/update")
	public void updateTestMetadata(@RequestBody TestMetadataResponseHolder req) {
		testService.updateTestMetadata(req);
	}

	@GetMapping("/list-all")
	public @ResponseBody List<Test> getListOfTests() {
		return testService.listAll();
	}

	@DeleteMapping("/{id}/delete")
	public void deleteTestById(@PathVariable String id) {
		String[] idArr = id.split(",");
		testService.deleteTestByIds(idArr);
	}
	
	@GetMapping("/list-all/{moduleName}")
	public Page<Test> getListOfTestsByModule(@PathVariable String moduleName, Pageable pageable){
		return testService.getTestsBasedOnModule(moduleName, pageable);
	}
	
	@GetMapping
	public Page<Test> getMatchedTests(@RequestParam(value = "filter") String filter, Pageable pageable){
		return testService.filterTests(filter, pageable);
	}

}

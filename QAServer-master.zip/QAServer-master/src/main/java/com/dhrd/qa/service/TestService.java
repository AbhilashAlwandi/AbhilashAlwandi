package com.dhrd.qa.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.dhrd.qa.model.Test;
import com.dhrd.qa.model.TestMetadataRepoHolder;
import com.dhrd.qa.model.TestMetadataResponseHolder;
import com.dhrd.qa.repositories.TestMetadataRepo;
import com.dhrd.qa.repositories.TestRepository;

import cz.jirutka.rsql.parser.RSQLParser;
import cz.jirutka.rsql.parser.ast.Node;

@Service
public class TestService implements ITestService {

	@Autowired
	TestRepository testRepo;

	@Autowired
	KeywordService kwService;

	@Autowired
	TestMetadataRepo testMetadataRepo;

	@Override
	public void createTest(Test test) {
		testRepo.save(test);
	}

	@Override
	public List<Test> listAll() {
		return testRepo.findAll();
	}

	@Override
	public void deleteTestByIds(String[] arr) {
		for (int i = 0; i < arr.length; i++)
			testRepo.deleteById(Long.valueOf(arr[i].trim()));
	}

	@Override
	public Page<Test> getTestsBasedOnModule(String module, Pageable pageable) {
		Page<Test> testListForModule = testRepo.getTestsForModule(module, pageable);
		return testListForModule;
	}

	@Override
	public TestMetadataResponseHolder getTestMetaData() {
		TestMetadataResponseHolder md = new TestMetadataResponseHolder();
		List<TestMetadataRepoHolder> testMetadataRepoList = testMetadataRepo.findAll();

		for (TestMetadataRepoHolder repo : testMetadataRepoList) {
			String value = repo.getValue() != null ? repo.getValue().trim() : repo.getValue();
			List<String> csvList = Arrays.asList(value.split(","));
			switch (repo.getIdentifier().trim()) {
			case "testGroup":
				md.setTestGroup(csvList);
				break;
			case "keywordType":
				md.setKeywordType(csvList);
				break;
			case "elementType":
				md.setElementType(csvList);
				break;
			case "identifierList":
				md.setIdentifierList(csvList);
				break;
			case "modules":
				md.setModules(csvList);
				break;
			default:
				throw new RuntimeException(repo.getIdentifier() + " is not valid");
			}
		}

		List<String> kws = kwService.getAllKeywords();

		md.setKwList(kws);

		return md;
	}

	@Override
	public Page<Test> filterTests(String filter, Pageable pageable) {
		Node rootNode = new RSQLParser().parse(filter);
		Specification<Test> spec = rootNode.accept(new CustomRsqlVisitor<Test>());
		return testRepo.findAll(spec, pageable);
	}

	@Override
	public void updateTestMetadata(TestMetadataResponseHolder req) {
		String testGroup = convertListToCsv(req.getTestGroup());
		String kwType = convertListToCsv(req.getKeywordType());
		String elementType = convertListToCsv(req.getElementType());
		String identifierList = convertListToCsv(req.getIdentifierList());
		String modules = convertListToCsv(req.getModules());

		testMetadataRepo.updateValue("testGroup", testGroup);
		testMetadataRepo.updateValue("keywordType", kwType);
		testMetadataRepo.updateValue("elementType", elementType);
		testMetadataRepo.updateValue("identifierList", identifierList);
		testMetadataRepo.updateValue("modules", modules);

	}

	private String convertListToCsv(List<String> list) {
		String csv = "";
		for (int i = 0; i < list.size(); i++)
			csv += list.get(i).trim() + ",";
		csv = csv.substring(0, csv.length() - 1);
		return csv;
	}
}

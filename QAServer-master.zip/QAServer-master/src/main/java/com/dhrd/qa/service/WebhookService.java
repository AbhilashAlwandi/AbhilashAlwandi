package com.dhrd.qa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.dhrd.qa.model.Webhook;
import com.dhrd.qa.model.WebhookContent;
import com.dhrd.qa.repositories.WebhookRepo;

@Service
public class WebhookService implements IWebhookService {

	@Autowired
	WebhookRepo webhookRepo;

	@Override
	public Webhook register() {
		Webhook webhook = new Webhook();
		webhook = webhookRepo.save(webhook);
		return webhook;
	}

	@Override
	public Webhook register(Webhook webhook1) {
		Webhook webhook = new Webhook();
		webhook.setReturnResponse(webhook1.getReturnResponse());
		webhook = webhookRepo.save(webhook);
		return webhook;
	}

	@Override
	public String store(String requestHeader, String content, Long id) {
		Webhook hook = new Webhook();
		hook.setId(id);
		WebhookContent webhookContent = new WebhookContent();
		Webhook webhook = webhookRepo.getOne(id);
		hook.setReturnResponse(webhook.getReturnResponse());
		List<WebhookContent> list = webhook.getWebhookContent();
		webhookContent.setBody(content);
		webhookContent.setHeader(requestHeader);
		list.add(webhookContent);
		hook.setWebhookContent(list);
		webhookRepo.save(hook);

		String str = webhook.getReturnResponse();

		if (str == null) {
			return "";
		} else
			return str;
	}

	@Override
	public Page<WebhookContent> getWebhookContent(Long uuid, Pageable pageable) {
		Page<WebhookContent> webhookContent = new PageImpl<>(webhookRepo.getOne(uuid).getWebhookContent());
		return webhookContent;
	}

	@Override
	public void delete(Long uuid) {
		webhookRepo.deleteById(uuid);
	}

}

package com.dhrd.qa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.dhrd.qa.model.DmAuthToken;
import com.dhrd.qa.model.ITestUtilityService;
import com.dhrd.qa.service.ICsdkService;

@RestController
@RequestMapping("/test_utility")
public class TestUtilityController {

	@Autowired
	public ITestUtilityService testUtilityService;
	
	@Autowired
	private ICsdkService csdkService;

	@PostMapping("/auth_token_dm")
	public DmAuthToken getAuthTokenForDm(@RequestBody DmAuthToken obj) throws Exception {
		return testUtilityService.getAuthTokenForDm(obj);
	}

	@PutMapping("/upload_reports")
	public String uploadReports(@RequestParam("file") MultipartFile file, @RequestParam("env") String env,
			@RequestParam("tenant") String tenant) {
		return testUtilityService.uploadReports(file,env,tenant);
	}
	
	@DeleteMapping("/cleanup_chrome_driver_for_tag")
	public void cleanupChromeDriverForTag(@RequestParam String tag) throws Exception {
		csdkService.cleanupChromeDriverForTag(tag);
	}

}

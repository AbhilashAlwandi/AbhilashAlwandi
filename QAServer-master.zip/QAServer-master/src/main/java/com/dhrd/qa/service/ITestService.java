package com.dhrd.qa.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.dhrd.qa.model.Test;
import com.dhrd.qa.model.TestMetadataResponseHolder;

public interface ITestService {
	
	public void createTest(Test test);

	public List<Test> listAll();

	public void deleteTestByIds(String[] arr);
	
	public TestMetadataResponseHolder getTestMetaData() ;

	Page<Test> getTestsBasedOnModule(String module, Pageable pageable);
	
	Page<Test> filterTests(String filter, Pageable pageable);

	public void updateTestMetadata(TestMetadataResponseHolder req);

}

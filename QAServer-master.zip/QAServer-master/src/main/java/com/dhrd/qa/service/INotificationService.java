package com.dhrd.qa.service;

public interface INotificationService {
	
	public void sendNotification(String to, String subject, String body) ;

}

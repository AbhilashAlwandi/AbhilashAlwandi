package com.dhrd.qa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dhrd.qa.model.NotificationModel;
import com.dhrd.qa.service.INotificationService;


@RestController
@RequestMapping("/notification")
public class NotificationController {
	
	@Autowired
	public INotificationService notificationService;
	
	@PostMapping("/send")
	public void sendNotification(@RequestBody NotificationModel notification) {
		notificationService.sendNotification(notification.getTo(), notification.getSubject(), notification.getBody());
	}

}

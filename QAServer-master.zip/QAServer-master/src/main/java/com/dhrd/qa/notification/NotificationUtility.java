package com.dhrd.qa.notification;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.dhrd.qa.utilities.ConfigProperties;

/**
 * 
 * @author kiran.nayak This utility helps in sending the notification to
 *         concerned parties
 *
 */
public class NotificationUtility {

	public static void sendEmail(String from, String to, String subject, String content, String nOTIFICATION_AWS_REGION,
			String nOTIFICATION_AWS_ACCESSKEYID, String nOTIFICATION_AWS_SECRETKEY) {
		if (to.length() != 0) {
			Notification notification = new AmazonSES(nOTIFICATION_AWS_REGION, nOTIFICATION_AWS_ACCESSKEYID,
					nOTIFICATION_AWS_SECRETKEY);
			notification.setFrom(from);
			notification.setSubject(subject);
			notification.setContent("<pre>" + content + "</pre>");
			notification.setTo(to);
			notification.send();
		} else {
			throw new RuntimeException("Nobody to send email to. Please configure");
		}
	}

}

package com.dhrd.qa.utilities;

import java.util.Properties;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.config.SslConfigs;

/**
 * @author kiran.nayak
 * @description Java client which publishes events to kafka broker
 *
 */
public class KafkaProducerClient {

	private Producer<String, Object> producer;

	public void sendEvents(String bootstrapServer, String sslTrustStoreLocation, String sslTrustStorePass, String sslPasswordConfig, String sslPasswordPass, String topic, String events) {
		ProducerRecord<String, Object> producerRecord = new ProducerRecord<>(topic, events);
		
		Properties properties = new Properties();
		
		properties.put("bootstrap.servers", bootstrapServer);
		properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		// Authentication
		properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
		properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslTrustStoreLocation);
		properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, sslTrustStorePass);

		// configure the following three settings for SSL Authentication
		properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, sslPasswordConfig);
		properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, sslPasswordPass);
		properties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, sslPasswordPass);

		properties.put(ProducerConfig.ACKS_CONFIG, "all");
		properties.put(ProducerConfig.RETRIES_CONFIG, 0);

		producer = new KafkaProducer<>(properties);

		System.out.println("Sending events : " + events + " to topic " + topic);

		producer.send(producerRecord);
		producer.close();
	}

}
